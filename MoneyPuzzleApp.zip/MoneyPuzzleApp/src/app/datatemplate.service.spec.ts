import { TestBed } from '@angular/core/testing';

import { DatatemplateService } from './datatemplate.service';

describe('DatatemplateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DatatemplateService = TestBed.get(DatatemplateService);
    expect(service).toBeTruthy();
  });
});
