import { Component } from '@angular/core';
import { ResultPage } from "src/app/result/result.page";
import { Router } from "@angular/router";
import { NavigationExtras } from "@angular/router";
import { ActivatedRoute } from "@angular/router";
import { DragulaService } from 'ng2-dragula';
import { AlertController} from "@ionic/angular";

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})

/*
1penny=1 cents
1nickel=5 cents
1dime=10 cents
4quarter=100 cents
100cents=1 dollar
*/
export class Tab1Page {
 
  val=0;
  nickleimages=[];
 dimeimages=[];
 quarterimages=[];
 halfdollarimages=[];
 pennyimages=[];
 ctr=0;
 puzzle_image=[];
 no=1;
 currentCoin='Nickle'
im;
  constructor(private dragulaService: DragulaService,private router: Router,public alertController: AlertController) {
     this.puzzle_image=[ {no:1,image:"assets/nickel.png",name:"Nickle",row:4,col:5},
      {no:2,image:"assets/dime.jpg",name:"Dime",row:2,col:5},
      {no:3,image:"assets/quarter.png",name:"Quarter",row:2,col:2},
      {no:4,image:"assets/halfdollar.jpg",name:"HalfDollar",row:1,col:2},
      {no:5,image:"assets/penny.jpg",name:"Penny",row:10,col:10}
    ]
    
  }

 placeCoin(image){
//this.images[this.ctr++]=image;
//console.log(this.images)
this.ionViewWillEnter()
if(this.currentCoin=='Nickle'){//NICKEL
  console.log(image)
  console.log("Current Coin is Nickle")
  if(image == "assets/penny.jpg"){
    if(this.nickleimages[4]=='assets/penny.jpg'){
      console.log("You can't insert another Coin")
      this.looseAlert()
    }
    else{
    console.log("Current Coin is Penny")
    this.nickleimages[this.ctr++]=image;
    console.log(this.nickleimages)
    this.ionViewWillEnter()
    if(this.ctr==5){
      this.winAlert();
    }
    }
  }
  }else if(this.currentCoin=='Dime'){//DIME
    console.log(image)
    console.log("Current Coin is Dime")
    if(image == "assets/penny.jpg"){
      if(this.dimeimages[9]=='assets/penny.jpg' || this.dimeimages[1]=="assets/nickel.png"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }
      else{
      console.log("Current Coin is Penny")
      this.dimeimages[this.ctr++]=image;
      console.log(this.dimeimages)
      this.ionViewWillEnter()
      }
    }else if(image == "assets/nickel.png"){
      if(this.dimeimages[1]=="assets/nickel.png" || this.dimeimages[9]=='assets/penny.jpg' ){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }else{
        console.log("Current Coin is Nickel")
        this.dimeimages[this.ctr++]=image;
        console.log(this.dimeimages)
        this.ionViewWillEnter()
      }
    }
  }else if(this.currentCoin=='Quarter'){//QUARTER
    console.log(image)
    console.log("Current Coin is Quarter")
    if(image == "assets/penny.jpg"){
      if(this.quarterimages[1]=="assets/dime.jpg"||this.quarterimages[0]=="assets/nickel.png"||this.quarterimages[4]=="assets/penny.jpg"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }
       else if(this.quarterimages[24]=='assets/penny.jpg' || this.quarterimages[4]=="assets/nickel.png"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }
      else{
      console.log("Current Coin is Penny")
      this.quarterimages[this.ctr++]=image;
      console.log(this.quarterimages)
      this.ionViewWillEnter()
      }
    }else if(image == "assets/nickel.png"){
      if(this.quarterimages[1]=="assets/dime.jpg"||this.quarterimages[0]=="assets/nickel.png"||this.quarterimages[4]=="assets/penny.jpg"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }
      else if(this.quarterimages[4]=="assets/nickel.png" || this.quarterimages[24]=='assets/penny.jpg'){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }else{
        console.log("Current Coin is Nickel")
        this.quarterimages[this.ctr++]=image;
        console.log(this.quarterimages)
        this.ionViewWillEnter()
      }
    }else if(image == "assets/dime.jpg"){
      if(this.quarterimages[1]=="assets/dime.jpg"||this.quarterimages[0]=="assets/nickel.png"||this.quarterimages[4]=="assets/penny.jpg"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }else{
        console.log("Current Coin is Dime")
        this.quarterimages[this.ctr++]=image;
        console.log(this.quarterimages)
        this.ionViewWillEnter()
      }
    }
  }else if(this.currentCoin=='HalfDollar'){ //HalfDollar
    console.log(image)
    console.log("Current Coin is HalfDollar")
    if(image == "assets/penny.jpg"){
      if(this.halfdollarimages[1] == "assets/quarter.png"||this.halfdollarimages[49]=='assets/penny.jpg' || this.halfdollarimages[9]=="assets/nickel.png"|| this.halfdollarimages[4]=="assets/dime.jpg"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }
      else{
      console.log("Current Coin is Penny")
      this.halfdollarimages[this.ctr++]=image;
      console.log(this.halfdollarimages)
      this.ionViewWillEnter()
      }
    }else if(image == "assets/quarter.png"){
      if(this.halfdollarimages[1] == "assets/quarter.png"||this.halfdollarimages[49]=='assets/penny.jpg' || this.halfdollarimages[9]=="assets/nickel.png"|| this.halfdollarimages[4]=="assets/dime.jpg"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }
      else{
      console.log("Current Coin is Quarter")
      this.halfdollarimages[this.ctr++]=image;
      console.log(this.halfdollarimages)
      this.ionViewWillEnter()
      }
    }else if(image == "assets/dime.jpg"){
      if(this.halfdollarimages[1] == "assets/quarter.png"||this.halfdollarimages[9]=="assets/nickel.png" || this.halfdollarimages[49]=='assets/penny.jpg'||this.halfdollarimages[4]=="assets/dime.jpg"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }else{
        console.log("Current Coin is Dime")
        this.halfdollarimages[this.ctr++]=image;
        console.log(this.halfdollarimages)
        this.ionViewWillEnter()
      }
    }else if(image == "assets/nickel.png"){
      if(this.halfdollarimages[1] == "assets/quarter.png"||this.halfdollarimages[9]=="assets/nickel.png" || this.halfdollarimages[49]=='assets/penny.jpg' || this.halfdollarimages[4]=="assets/dime.jpg"){
        console.log("You can't insert another Coin")
        this.looseAlert()
      }else{
        console.log("Current Coin is Nickel")
        this.halfdollarimages[this.ctr++]=image;
        console.log(this.halfdollarimages)
        this.ionViewWillEnter()
      }
    }
  }
 }


 async winAlert() {
  const alert = await this.alertController.create({
    
    header: 'Congratulations',
    subHeader: 'You Made it !!',
    buttons: [
      {
        text: 'Ok',
        handler: () => {
          console.log('Confirm Ok')
          
          this.router.navigate(['tabs/tab1']);
        },
      },
    ],
  });

  await alert.present();
}


async looseAlert() {
  const alert = await this.alertController.create({
   
    header: 'Sorry',
    subHeader: 'You Loose !!',
    buttons: [
      {
        text: 'Ok',
        handler: () => {
          console.log('Confirm Ok')
        
          this.router.navigate(['tabs/tab1']);
        },
      },
    ],
  
  });

  await alert.present();
}


 ionViewWillEnter(){
  console.log("Updating ..")
  console.log(this.currentCoin)
 }

 ngOnChange(no,name){
    if(this.no==5){
       this.no=1;
    }
    else{
       this.no=no+1;
    }
    this.currentCoin=name;
    this.ionViewWillEnter()
    console.log(this.currentCoin)
    //this.images
    this.ionViewWillEnter();
   }

   
}