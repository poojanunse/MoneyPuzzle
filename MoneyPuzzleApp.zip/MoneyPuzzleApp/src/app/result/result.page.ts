import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ActivatedRoute, NavigationExtras } from "@angular/router";
import { AlertController, LoadingController } from "@ionic/angular";

@Component({
  selector: 'app-result',
  templateUrl: './result.page.html',
  styleUrls: ['./result.page.scss'],
})
export class ResultPage implements OnInit {
 
  ques;
  ans
  sum=0;
  tt;
  displaytt=0;
 no;

  constructor(private route: ActivatedRoute, private router: Router,public alertController: AlertController,
    public loadingController: LoadingController) { 
    
    this.route.queryParams.subscribe(params => {
      if (params && params.ques) {
        this.ques = params.ques
        this.ans=params.ans;
        this.no=params.no
      }
    });
    this.tt=this.ans;
  
    console.log(this.ques)
    console.log(this.ans)
    console.log(this.tt)
    console.log(this.no)

   
  }

  async winAlert() {
    const alert = await this.alertController.create({
      
      header: 'Congratulations',
      subHeader: 'You Made it !!',
      buttons: [
        {
          text: 'Ok',
          handler: () => {
            console.log('Confirm Ok')
            let navigationExtras: NavigationExtras = {
              queryParams: {
                no:this.no
          
              }
            };
            this.router.navigate(['tabs'], navigationExtras);
          },
        },
      ],
    });

    await alert.present();
  }


  async looseAlert() {
    const alert = await this.alertController.create({
     
      header: 'Sorry',
      subHeader: 'You Loose !!',
      buttons: [
        {
          text: 'Ok',
          handler: () => {
            console.log('Confirm Ok')
            let navigationExtras: NavigationExtras = {
              queryParams: {
                no:this.no
          
              }
            };
            this.router.navigate(['tabs'], navigationExtras);
          },
        },
      ],
    
    });

    await alert.present();
  }

  async presentLoadingWithOptions() {
    const loading = await this.loadingController.create({
      spinner: null,
      duration: 5000,
      message: 'Please wait...',
      translucent: true,
      cssClass: 'custom-class custom-loading'
    });
    return await loading.present();
  }

 cal(no){
   //this.displaytt=no.toInt+this.displaytt;
   console.log(no)
this.tt=this.tt-no;
console.log(this.tt)
if(this.tt==0){
  console.log("You Made !!")
  this.tt=this.ans
  this.winAlert();
}else if(this.tt<0){
  console.log("You Loose !!")
  this.tt=this.ans
  this.looseAlert();
}
 }

 playAgain(){
   this.displaytt=0;
  this.presentLoadingWithOptions()
  this.tt=this.ans;
 }

 onQuit(){
  let navigationExtras: NavigationExtras = {
    queryParams: {
      no:this.no

    }
  };
  this.router.navigate(['tabs'], navigationExtras);
 }

  ngOnInit() {
  }

}
