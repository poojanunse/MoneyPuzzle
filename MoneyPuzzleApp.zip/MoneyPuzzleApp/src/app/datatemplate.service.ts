import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DatatemplateService {
  static ques: any;
  
  static op1='';
  static op2='';
  static op3='';
  static op4='';
  static ans='';
  constructor() { }

  public static setter(ques,op1,op2,op3,op4){

  }
  public static getter_ques(){
  return this.ques;
  }
  public static getter_ans(){
    return this.ans;
    }
    public static getter_op1(){
      return this.op1;
      }
      public static getter_op2(){
        return this.op2;
        }
      public static getter_op3(){
          return this.op3;
          }
          public static getter_op4(){
            return this.op4;
            }
}
