(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab1-tab1-module"],{

/***/ "./src/app/tab1/tab1.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/*! exports provided: Tab1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function() { return Tab1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab1.page */ "./src/app/tab1/tab1.page.ts");







var Tab1PageModule = /** @class */ (function () {
    function Tab1PageModule() {
    }
    Tab1PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"] }])
            ],
            declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"]]
        })
    ], Tab1PageModule);
    return Tab1PageModule;
}());



/***/ }),

/***/ "./src/app/tab1/tab1.page.html":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n\n    <ion-title   color=\"warning\" style=\"text-align:center;\">\n        Money Puzzle !!\n    </ion-title>\n  \n  </ion-toolbar>\n</ion-header>\n<ion-content style=\"text-align:center;\">\n  <ion-card class=\"card\" \n  style=\"margin:10%;\n   box-shadow: 0 4px 8px 0 rgba(0,0,0,0.4);\n  transition: 0.3s;\">\n  <ion-list  *ngFor=\"let q of questions\"> \n    <div *ngIf=\"ctr==q.no\">\n      <h5>\n        <ion-label>{{q.ques}}</ion-label>\n      </h5>\n      <ion-grid>\n        <ion-col>\n      <ion-button  color=\"success\"  size=\"large\" (click)=\"navResult(q.ques,q.ans)\" routerDirection=\"forward\">Play</ion-button>\n        </ion-col>\n        <ion-col>\n      <ion-button  color=\"danger\"  size=\"large\" (click)=\"ngOnChange(ctr)\" >Next</ion-button>\n        </ion-col>\n      </ion-grid>\n    </div>\n  </ion-list>\n  </ion-card>\n \n</ion-content>"

/***/ }),

/***/ "./src/app/tab1/tab1.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".welcome-card ion-img {\n  max-height: 35vh;\n  overflow: hidden; }\n\n.con {\n  background-color: royalblue; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMS9DOlxceGFtcHBcXGh0ZG9jc1xcaW9uaWNcXGdhbWVjdXJyZW5jeS9zcmNcXGFwcFxcdGFiMVxcdGFiMS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBZ0I7RUFDaEIsZ0JBQWdCLEVBQUE7O0FBRWxCO0VBQ0UsMkJBQTJCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC90YWIxL3RhYjEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndlbGNvbWUtY2FyZCBpb24taW1nIHtcbiAgbWF4LWhlaWdodDogMzV2aDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbi5jb257XG4gIGJhY2tncm91bmQtY29sb3I6IHJveWFsYmx1ZTtcbn1cblxuIl19 */"

/***/ }),

/***/ "./src/app/tab1/tab1.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/*! exports provided: Tab1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1Page", function() { return Tab1Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var Tab1Page = /** @class */ (function () {
    function Tab1Page(route, router) {
        var _this = this;
        this.route = route;
        this.router = router;
        this.qtr_count = 0;
        this.pen_count = 0;
        this.nick_count = 0;
        this.dime_count = 0;
        this.cents_count = 0;
        this.halfdollar_count = 0;
        this.questions = [];
        this.ctr = 1;
        this.route.queryParams.subscribe(function (params) {
            if (params && params.ques) {
                _this.ctr = params.no;
            }
        });
        console.log(this.ctr);
        console.log("Within Init()");
        this.questions = [{ no: 1, ques: "How Many Nickels do you need to make 10 cents?", ans: "2", op1: "hundred", op2: "seventy five", op3: "thirty", op4: "two" },
            { no: 2, ques: "How Many dimes do you need to make 20 cents?", ans: "2", op1: "two", op2: "ten", op3: "ninety", op4: "sixty" },
            { no: 3, ques: "How Many pennies do you need to make 10 cents?", ans: "10", op1: "two", op2: "ten", op3: "one", op4: "twenty five" },
            { no: 4, ques: "How Many cents do you need to make 1 dollar?", ans: "100", op1: "three", op2: "nine", op3: "ten", op4: "hundred" },
            { no: 5, ques: "How Many Nickels do you need to make 25 cents?", ans: "5", op1: "five", op2: "two", op3: "six", op4: "three" },
            { no: 6, ques: "How Many quarters do you need to make 100 cents?", ans: "4", op1: "fifty", op2: "hundred", op3: "ten", op4: "four" },
            { no: 7, ques: "How Many quarters do you need to make 75 cents?", ans: "3", op1: "eight", op2: "three", op3: "twenty five", op4: "ten" },
            { no: 8, ques: "How Many dimes do you need to make 70 cents?", ans: "7", op1: "twenty five", op2: "two", op3: "seven", op4: "thirty" },
            { no: 9, ques: "How Many Nickels do you need to make 50 cents?", ans: "10", op1: "five", op2: "ten", op3: "one", op4: "seven" },
            { no: 10, ques: "How Many dimes do you need to make 40 cents?", ans: "4", op1: "two", op2: "ten", op3: "fifty", op4: "four" },
        ];
        console.log(this.questions);
    }
    Tab1Page.prototype.navResult = function (ques, ans) {
        var navigationExtras = {
            queryParams: {
                ques: ques,
                ans: ans,
                no: this.ctr++
            }
        };
        if (this.ctr != 11) {
            this.router.navigate(['result'], navigationExtras);
        }
        else if (this.ctr == 11) {
            this.ctr = 1;
            this.ionViewWillEnter();
        }
        /*if(this.ctr==11){
          this.ctr=1;
          this.ionViewWillEnter();
        }else{
        this.router.navigate(['result'], navigationExtras);
        }*/
    };
    Tab1Page.prototype.ionViewWillEnter = function () {
        console.log("jdhkj");
        console.log(this.ctr);
        this.questions = [{ no: 1, ques: "How Many Nickels do you need to make 10 cents?", ans: "2", op1: "hundred", op2: "seventy five", op3: "thirty", op4: "two" },
            { no: 2, ques: "How Many dimes do you need to make 20 cents?", ans: "2", op1: "two", op2: "ten", op3: "ninety", op4: "sixty" },
            { no: 3, ques: "How Many pennies do you need to make 10 cents?", ans: "10", op1: "two", op2: "ten", op3: "one", op4: "twenty five" },
            { no: 4, ques: "How Many cents do you need to make 1 dollar?", ans: "100", op1: "three", op2: "nine", op3: "ten", op4: "hundred" },
            { no: 5, ques: "How Many Nickels do you need to make 25 cents?", ans: "5", op1: "five", op2: "two", op3: "six", op4: "three" },
            { no: 6, ques: "How Many quarters do you need to make 100 cents?", ans: "4", op1: "fifty", op2: "hundred", op3: "ten", op4: "four" },
            { no: 7, ques: "How Many quarters do you need to make 75 cents?", ans: "3", op1: "eight", op2: "three", op3: "twenty five", op4: "ten" },
            { no: 8, ques: "How Many dimes do you need to make 70 cents?", ans: "7", op1: "twenty five", op2: "two", op3: "seven", op4: "thirty" },
            { no: 9, ques: "How Many Nickels do you need to make 50 cents?", ans: "10", op1: "five", op2: "ten", op3: "one", op4: "seven" },
            { no: 10, ques: "How Many dimes do you need to make 40 cents?", ans: "4", op1: "two", op2: "ten", op3: "fifty", op4: "four" }
        ];
    };
    Tab1Page.prototype.ngOnChange = function (no) {
        console.log(no);
        this.ionViewWillEnter();
        if (no <= 9) {
            this.ctr = no + 1;
        }
        else {
            this.ctr = 1;
        }
        this.ionViewWillEnter();
        console.log(this.ctr);
    };
    Tab1Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab1',
            template: __webpack_require__(/*! ./tab1.page.html */ "./src/app/tab1/tab1.page.html"),
            styles: [__webpack_require__(/*! ./tab1.page.scss */ "./src/app/tab1/tab1.page.scss")]
        })
        /*
        1penny=1 cents
        1nickel=5 cents
        1dime=10 cents
        4quarter=100 cents
        100cents=1 dollar
        */
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], Tab1Page);
    return Tab1Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab1-tab1-module.js.map